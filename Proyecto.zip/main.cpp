#include <stdio.h>

// Definici�n de constantes
#define MAX_USUARIOS 10
#define MAX_NOMBRE 10
#define MAX_PASSWORD 10
#define NIVELES 5
#define MAX_SIZE 15

// Estructuras
struct Usuario {
    char nombre[MAX_NOMBRE];
    char password[MAX_PASSWORD];
    int juegosJugados;
    int juegosGanados;
    int juegosPerdidos;
};

// Variables globales
struct Usuario usuarios[MAX_USUARIOS];
int numUsuarios = 0;
int usuarioActual = -1;

// Laberintos (0 = camino, 1 = pared, 2 = meta)
int laberintos[NIVELES][MAX_SIZE][MAX_SIZE] = {
    // Nivel 1 (5x5)
    {
        {1,1,1,1,1},
        {1,0,0,0,1},
        {1,1,1,0,1},
        {1,2,0,0,1},
        {1,1,1,1,1}
    },
    // Nivel 2 (7x7)
    {
        {1,1,1,1,1,1,1},
        {1,0,0,0,0,0,1},
        {1,1,1,1,1,0,1},
        {1,0,0,0,0,0,1},
        {1,0,1,1,1,1,1},
        {1,0,0,0,2,0,1},
        {1,1,1,1,1,1,1}
    },
    // Nivel 3 (9x9)
    {
        {1,1,1,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,0,1},
        {1,0,0,0,0,0,0,0,1},
        {1,0,1,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,0,1},
        {1,2,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1}
    }
};

int tamanoNivel[NIVELES] = {5, 7, 9, 11, 13};
int movimientosOptimos[NIVELES] = {6, 10, 14, 18, 22};

// Funci�n para comparar strings
int compararStrings(char str1[], char str2[]) {
    int i = 0;
    while(str1[i] != '\0' && str2[i] != '\0') {
        if(str1[i] != str2[i]) {
            return 0;
        }
        i++;
    }
    return (str1[i] == '\0' && str2[i] == '\0');
}

void limpiarPantalla() {
    printf("\033[2J\033[H");
}

int mostrarMenu() {
    int opcion;
    limpiarPantalla();
    printf("\n=== JUEGO DEL LABERINTO ===\n");
    printf("1. Iniciar sesion\n");
    printf("2. Crear usuario\n");
    printf("3. Ver estadisticas\n");
    printf("4. Salir\n");
    printf("Seleccione una opcion: ");
    scanf("%d", &opcion);
    return opcion;
}

void crearUsuario() {
    if(numUsuarios >= MAX_USUARIOS) {
        printf("\nNo se pueden crear mas usuarios. Limite alcanzado.\n");
        printf("Presione Enter para continuar...");
        getchar();
        getchar();
        return;
    }
    
    printf("\nIngrese nombre de usuario (max %d caracteres): ", MAX_NOMBRE - 1);
    scanf("%s", usuarios[numUsuarios].nombre);
    printf("Ingrese contrasena (max %d caracteres): ", MAX_PASSWORD - 1);
    scanf("%s", usuarios[numUsuarios].password);
    
    usuarios[numUsuarios].juegosJugados = 0;
    usuarios[numUsuarios].juegosGanados = 0;
    usuarios[numUsuarios].juegosPerdidos = 0;
    
    numUsuarios++;
    printf("\nUsuario creado exitosamente!\n");
    printf("Presione Enter para continuar...");
    getchar();
    getchar();
}

int iniciarSesion() {
    char nombre[MAX_NOMBRE];
    char password[MAX_PASSWORD];
    printf("\nIngrese nombre de usuario: ");
    scanf("%s", nombre);
    printf("Ingrese contrasena: ");
    scanf("%s", password);
    
    for(int i = 0; i < numUsuarios; i++) {
        if(compararStrings(usuarios[i].nombre, nombre) && 
           compararStrings(usuarios[i].password, password)) {
            usuarioActual = i;
            return 1;
        }
    }
    return 0;
}

void mostrarEstadisticas() {
    if(usuarioActual != -1) {
        printf("\n=== Estadisticas de %s ===\n", usuarios[usuarioActual].nombre);
        printf("Juegos jugados: %d\n", usuarios[usuarioActual].juegosJugados);
        printf("Juegos ganados: %d\n", usuarios[usuarioActual].juegosGanados);
        printf("Juegos perdidos: %d\n", usuarios[usuarioActual].juegosPerdidos);
    } else {
        printf("\nDebe iniciar sesion primero.\n");
    }
    printf("Presione Enter para continuar...");
    getchar();
    getchar();
}

void dibujarLaberinto(int nivel, int posX, int posY) {
    limpiarPantalla();
    printf("\nNivel %d\n", nivel + 1);
    
    for(int i = 0; i < tamanoNivel[nivel]; i++) {
        for(int j = 0; j < tamanoNivel[nivel]; j++) {
            if(i == posX && j == posY)
                printf("P "); // Jugador
            else if(laberintos[nivel][i][j] == 1)
                printf("# "); // Pared (cambiado de � a # para mejor compatibilidad)
            else if(laberintos[nivel][i][j] == 2)
                printf("M "); // Meta
            else
                printf("  "); // Camino
        }
        printf("\n");
    }
}

void jugarNivel(int nivel) {
    int posX = 1, posY = 1;
    int movimientos = 0;
    char tecla;
    int nivelCompleto = 0;
    int choque = 0;
    
    while(!nivelCompleto && !choque) {
        dibujarLaberinto(nivel, posX, posY);
        printf("\nMovimientos: %d\n", movimientos);
        printf("Use W,A,S,D para moverse (X para salir): ");
        
        scanf(" %c", &tecla);
        int nuevaX = posX;
        int nuevaY = posY;
        
        // Convertir a min�scula manualmente
        if(tecla >= 'A' && tecla <= 'Z') {
            tecla = tecla + 32;
        }
        
        switch(tecla) {
            case 'w': nuevaX--; break;
            case 's': nuevaX++; break;
            case 'a': nuevaY--; break;
            case 'd': nuevaY++; break;
            case 'x': return;
        }
        
        if(laberintos[nivel][nuevaX][nuevaY] != 1) {
            posX = nuevaX;
            posY = nuevaY;
            movimientos++;
            
            if(laberintos[nivel][posX][posY] == 2) {
                nivelCompleto = 1;
                usuarios[usuarioActual].juegosGanados++;
            }
        } else {
            choque = 1;
        }
    }
    
    if(nivelCompleto) {
        printf("\nNivel completado!\n");
        printf("Movimientos realizados: %d\n", movimientos);
        printf("Movimientos optimos: %d\n", movimientosOptimos[nivel]);
        printf("Presione Enter para continuar...");
        getchar();
        getchar();
    } else if(choque) {
        printf("\nHas chocado con una pared!\n");
        usuarios[usuarioActual].juegosPerdidos++;
        printf("1. Reintentar nivel\n");
        printf("2. Volver al menu principal\n");
        int opcion;
        scanf("%d", &opcion);
        if(opcion == 1) {
            jugarNivel(nivel);
        }
    }
}

int main() {
    int opcion;
    do {
        opcion = mostrarMenu();
        switch(opcion) {
            case 1:
                if(iniciarSesion()) {
                    printf("\nBienvenido %s!\n", usuarios[usuarioActual].nombre);
                    printf("Presione Enter para continuar...");
                    getchar();
                    getchar();
                    for(int nivel = 0; nivel < NIVELES; nivel++) {
                        usuarios[usuarioActual].juegosJugados++;
                        jugarNivel(nivel);
                    }
                } else {
                    printf("\nUsuario o contrasena incorrectos.\n");
                    printf("Presione Enter para continuar...");
                    getchar();
                    getchar();
                }
                break;
            case 2:
                crearUsuario();
                break;
            case 3:
                mostrarEstadisticas();
                break;
        }
    } while(opcion != 4);
    
    return 0;
}
